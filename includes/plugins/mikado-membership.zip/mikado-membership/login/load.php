<?php

require_once 'wordpress-login.php';