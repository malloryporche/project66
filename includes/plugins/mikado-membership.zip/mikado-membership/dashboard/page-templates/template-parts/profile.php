<div class="mkd-membership-dashboard-page">
	<h3 class="mkd-membership-dashboard-page-title">
		<?php esc_html_e( 'Profile', 'mikado-membership' ); ?>
	</h3>
	<div class="mkd-membership-dashboard-page-content">
		<div class="mkd-profile-image">
            <?php echo mkd_membership_kses_img( $profile_image ); ?>
        </div>
		<p>
			<span><?php esc_html_e( 'First Name', 'mikado-membership' ); ?>:</span>
			<?php echo depot_mikado_get_module_part($first_name); ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Last Name', 'mikado-membership' ); ?>:</span>
			<?php echo depot_mikado_get_module_part($last_name); ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Email', 'mikado-membership' ); ?>:</span>
			<?php echo depot_mikado_get_module_part($email); ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Description', 'mikado-membership' ); ?>:</span>
			<?php echo depot_mikado_get_module_part($description); ?>
		</p>
		<p>
			<span><?php esc_html_e( 'Website', 'mikado-membership' ); ?>:</span>
			<a href="<?php echo esc_url( $website ); ?>" target="_blank"><?php echo depot_mikado_get_module_part($website); ?></a>
		</p>
	</div>
</div>
