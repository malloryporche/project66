<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/mobile-slider/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/mobile-slider/mobile-slider.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/mobile-slider/mobile-slider-item.php';