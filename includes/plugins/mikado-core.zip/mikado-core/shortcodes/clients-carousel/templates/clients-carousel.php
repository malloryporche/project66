<div class="mkd-clients-carousel-holder <?php echo esc_attr($holder_classes); ?>">
	<div class="mkd-cc-inner" <?php echo depot_mikado_get_inline_attrs($carousel_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>