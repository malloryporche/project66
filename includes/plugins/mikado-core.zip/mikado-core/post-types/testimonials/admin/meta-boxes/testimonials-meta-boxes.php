<?php

if(!function_exists('mkd_core_map_testimonials_meta')) {
    function mkd_core_map_testimonials_meta() {
        $testimonial_meta_box = depot_mikado_create_meta_box(
            array(
                'scope' => array('testimonials'),
                'title' => esc_html__('Testimonial', 'mikado-core'),
                'name' => 'testimonial_meta'
            )
        );

        depot_mikado_create_meta_box_field(
            array(
                'name'        	=> 'mkd_testimonial_title',
                'type'        	=> 'text',
                'label'       	=> esc_html__('Title', 'mikado-core'),
                'description' 	=> esc_html__('Enter testimonial title', 'mikado-core'),
                'parent'      	=> $testimonial_meta_box,
            )
        );

        depot_mikado_create_meta_box_field(
            array(
                'name'        	=> 'mkd_testimonial_text',
                'type'        	=> 'text',
                'label'       	=> esc_html__('Text', 'mikado-core'),
                'description' 	=> esc_html__('Enter testimonial text', 'mikado-core'),
                'parent'      	=> $testimonial_meta_box,
            )
        );

        depot_mikado_create_meta_box_field(
            array(
                'name'        	=> 'mkd_testimonial_author',
                'type'        	=> 'text',
                'label'       	=> esc_html__('Author', 'mikado-core'),
                'description' 	=> esc_html__('Enter author name', 'mikado-core'),
                'parent'      	=> $testimonial_meta_box,
            )
        );

        depot_mikado_create_meta_box_field(
            array(
                'name'        	=> 'mkd_testimonial_position',
                'type'        	=> 'text',
                'label'       	=> esc_html__('Author Position', 'mikado-core'),
                'description' 	=> esc_html__('Enter Author Position', 'mikado-core'),
                'parent'      	=> $testimonial_meta_box,
            )
        );
    }

    add_action('depot_mikado_meta_boxes_map', 'mkd_core_map_testimonials_meta', 95);
}