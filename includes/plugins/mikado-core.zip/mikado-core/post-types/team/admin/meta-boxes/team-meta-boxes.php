<?php

if(!function_exists('mkd_core_map_team_single_meta')) {
    function mkd_core_map_team_single_meta() {

        $meta_box = depot_mikado_create_meta_box(array(
            'scope' => 'team-member',
            'title' => esc_html__('Team Member Info', 'mikado-core'),
            'name'  => 'team_meta'
        ));

        depot_mikado_create_meta_box_field(array(
            'name'        => 'mkd_team_member_position',
            'type'        => 'text',
            'label'       => esc_html__('Position', 'mikado-core'),
            'description' => esc_html__('The members\'s role within the team', 'mikado-core'),
            'parent'      => $meta_box
        ));

        depot_mikado_create_meta_box_field(array(
            'name'        => 'mkd_team_member_birth_date',
            'type'        => 'date',
            'label'       => esc_html__('Birth date', 'mikado-core'),
            'description' => esc_html__('The members\'s birth date', 'mikado-core'),
            'parent'      => $meta_box
        ));

        depot_mikado_create_meta_box_field(array(
            'name'        => 'mkd_team_member_email',
            'type'        => 'text',
            'label'       => esc_html__('Email', 'mikado-core'),
            'description' => esc_html__('The members\'s email', 'mikado-core'),
            'parent'      => $meta_box
        ));

        depot_mikado_create_meta_box_field(array(
            'name'        => 'mkd_team_member_phone',
            'type'        => 'text',
            'label'       => esc_html__('Phone', 'mikado-core'),
            'description' => esc_html__('The members\'s phone', 'mikado-core'),
            'parent'      => $meta_box
        ));

        depot_mikado_create_meta_box_field(array(
            'name'        => 'mkd_team_member_address',
            'type'        => 'text',
            'label'       => esc_html__('Address', 'mikado-core'),
            'description' => esc_html__('The members\'s addres', 'mikado-core'),
            'parent'      => $meta_box
        ));

        depot_mikado_create_meta_box_field(array(
            'name'        => 'mkd_team_member_education',
            'type'        => 'text',
            'label'       => esc_html__('Education', 'mikado-core'),
            'description' => esc_html__('The members\'s education', 'mikado-core'),
            'parent'      => $meta_box
        ));

        depot_mikado_create_meta_box_field(array(
            'name'        => 'mkd_team_member_resume',
            'type'        => 'file',
            'label'       => esc_html__('Resume', 'mikado-core'),
            'description' => esc_html__('Upload members\'s resume', 'mikado-core'),
            'parent'      => $meta_box
        ));

        for($x = 1; $x < 6; $x++) {

            $social_icon_group = depot_mikado_add_admin_group(array(
                'name'   => 'mkd_team_member_social_icon_group'.$x,
                'title'  => esc_html__('Social Link ', 'mikado-core').$x,
                'parent' => $meta_box
            ));

                $social_row1 = depot_mikado_add_admin_row(array(
                    'name'   => 'mkd_team_member_social_icon_row1'.$x,
                    'parent' => $social_icon_group
                ));

                    DepotMikadoIconCollections::get_instance()->getSocialIconsMetaBoxOrOption(array(
                        'label' => esc_html__('Icon ', 'mikado-core').$x,
                        'parent' => $social_row1,
                        'name' => 'mkd_team_member_social_icon_pack_'.$x,
                        'defaul_icon_pack' => '',
                        'type' => 'meta-box',
                        'field_type' => 'simple'
                    ));

                $social_row2 = depot_mikado_add_admin_row(array(
                    'name'   => 'mkd_team_member_social_icon_row2'.$x,
                    'parent' => $social_icon_group
                ));

                    depot_mikado_create_meta_box_field(array(
                        'type'            => 'textsimple',
                        'label'           => esc_html__('Link', 'mikado-core'),
                        'name'            => 'mkd_team_member_social_icon_'.$x.'_link',
                        'hidden_property' => 'mkd_team_member_social_icon_pack_'.$x,
                        'hidden_value'    => '',
                        'parent'          => $social_row2
                    ));
	
			        depot_mikado_create_meta_box_field(array(
				        'type'          => 'selectsimple',
				        'label'         => esc_html__('Target', 'mikado-core'),
				        'name'          => 'mkd_team_member_social_icon_'.$x.'_target',
				        'options'       => depot_mikado_get_link_target_array(),
				        'hidden_property' => 'mkd_team_member_social_icon_'.$x.'_link',
				        'hidden_value'    => '',
				        'parent'          => $social_row2
			        ));
        }
    }

    add_action('depot_mikado_meta_boxes_map', 'mkd_core_map_team_single_meta', 46);
}