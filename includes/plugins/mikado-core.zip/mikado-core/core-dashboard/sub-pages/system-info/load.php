<?php

include_once MIKADO_CORE_ABS_PATH . '/core-dashboard/sub-pages/system-info/system-info.php';