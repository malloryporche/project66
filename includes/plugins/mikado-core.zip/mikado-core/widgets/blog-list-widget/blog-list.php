<?php

class DepotMikadoBlogListWidget extends DepotMikadoWidget {
    public function __construct() {
        parent::__construct(
            'mkd_blog_list_widget',
            esc_html__('Mikado Blog List Widget', 'mikado-core'),
            array( 'description' => esc_html__( 'Display a list of your blog posts', 'mikado-core'))
        );

        $this->setParams();
    }

    /**
     * Sets widget options
     */
    protected function setParams() {
        $this->params = array(
            array(
                'type'  => 'textfield',
                'name'  => 'widget_title',
                'title' => esc_html__('Widget Title', 'mikado-core')
            ),
            array(
                'type'    => 'dropdown',
                'name'    => 'type',
                'title'   => esc_html__('Type', 'mikado-core'),
                'options' => array(
                    'simple'  => esc_html__('Simple', 'mikado-core'),
                    'minimal' => esc_html__('Minimal', 'mikado-core')
                )
            ),
            array(
                'type'  => 'textfield',
                'name'  => 'number_of_posts',
                'title' => esc_html__('Number of Posts', 'mikado-core')
            ),
            array(
                'type'    => 'dropdown',
                'name'    => 'space_between_columns',
                'title'   => esc_html__('Space Between items', 'mikado-core'),
                'options' => array(
                    'normal' => esc_html__('Normal', 'mikado-core'),
                    'small'  => esc_html__('Small', 'mikado-core'),
                    'tiny'   => esc_html__('Tiny', 'mikado-core'),
                    'no'     => esc_html__('No Space', 'mikado-core')
                )
            ),
	        array(
		        'type'    => 'dropdown',
		        'name'    => 'order_by',
		        'title'   => esc_html__('Order By', 'mikado-core'),
		        'options' => depot_mikado_get_query_order_by_array()
	        ),
	        array(
		        'type'    => 'dropdown',
		        'name'    => 'order',
		        'title'   => esc_html__('Order', 'mikado-core'),
		        'options' => depot_mikado_get_query_order_array()
	        ),
            array(
                'type'        => 'textfield',
                'name'        => 'category',
                'title'       => esc_html__('Category Slug', 'mikado-core'),
                'description' => esc_html__('Leave empty for all or use comma for list', 'mikado-core')
            ),
            array(
                'type'    => 'dropdown',
                'name'    => 'title_tag',
                'title'   => esc_html__('Title Tag', 'mikado-core'),
                'options' => depot_mikado_get_title_tag(true)
            ),
            array(
                'type'    => 'dropdown',
                'name'    => 'title_transform',
                'title'   => esc_html__('Title Text Transform', 'mikado-core'),
                'options' => depot_mikado_get_text_transform_array(true)
            ),
        );
    }

    /**
     * Generates widget's HTML
     *
     * @param array $args args from widget area
     * @param array $instance widget's options
     */
    public function widget($args, $instance) {
        $params = '';

        if (!is_array($instance)) { $instance = array(); }

        $instance['post_info_section'] = 'yes';
        $instance['number_of_columns'] = '1';

        // Filter out all empty params
        $instance = array_filter($instance, function($array_value) { return trim($array_value) != ''; });

        //generate shortcode params
        foreach($instance as $key => $value) {
            $params .= " $key='$value' ";
        }

        $available_types = array('simple', 'classic');

        if (!in_array($instance['type'], $available_types)) {
            $instance['type'] = 'simple';
        }

        echo '<div class="widget mkd-blog-list-widget">';
            if(!empty($instance['widget_title'])) {
                echo depot_mikado_get_module_part($args['before_title'].$instance['widget_title'].$args['after_title']);
            }

            echo do_shortcode("[mkd_blog_list $params]"); // XSS OK
        echo '</div>';
    }
}