<?php

class DepotMikadoButtonWidget extends DepotMikadoWidget {
	public function __construct() {
		parent::__construct(
			'mkd_button_widget',
			esc_html__('Mikado Button Widget', 'mikado-core'),
			array( 'description' => esc_html__( 'Add button element to widget areas', 'mikado-core'))
		);

		$this->setParams();
	}

	/**
	 * Sets widget options
	 */
	protected function setParams() {
		$this->params = array(
			array(
				'type'    => 'dropdown',
				'name'    => 'type',
				'title'   => esc_html__('Type', 'mikado-core'),
				'options' => array(
					'solid'   => esc_html__('Solid', 'mikado-core'),
					'outline' => esc_html__('Outline', 'mikado-core'),
					'simple'  => esc_html__('Simple', 'mikado-core')
				)
			),
			array(
				'type'    => 'dropdown',
				'name'    => 'size',
				'title'   => esc_html__('Size', 'mikado-core'),
				'options' => array(
					'small'  => esc_html__('Small', 'mikado-core'),
					'medium' => esc_html__('Medium', 'mikado-core'),
					'large'  => esc_html__('Large', 'mikado-core'),
					'huge'   => esc_html__('Huge', 'mikado-core')
				),
				'description' => esc_html__('This option is only available for solid and outline button type', 'mikado-core')
			),
			array(
				'type'    => 'textfield',
				'name'    => 'text',
				'title'   => esc_html__('Text', 'mikado-core'),
				'default' => esc_html__('Button Text', 'mikado-core')
			),
			array(
				'type'  => 'textfield',
				'name'  => 'link',
				'title' => esc_html__('Link', 'mikado-core')
			),
			array(
				'type'    => 'dropdown',
				'name'    => 'target',
				'title'   => esc_html__('Link Target', 'mikado-core'),
				'options' => depot_mikado_get_link_target_array()
			),
			array(
				'type'  => 'textfield',
				'name'  => 'color',
				'title' => esc_html__('Color', 'mikado-core')
			),
			array(
				'type'  => 'textfield',
				'name'  => 'hover_color',
				'title' => esc_html__('Hover Color', 'mikado-core')
			),
			array(
				'type'        => 'textfield',
				'name'        => 'background_color',
				'title'       => esc_html__('Background Color', 'mikado-core'),
				'description' => esc_html__('This option is only available for solid button type', 'mikado-core')
			),
			array(
				'type'        => 'textfield',
				'name'        => 'hover_background_color',
				'title'       => esc_html__('Hover Background Color', 'mikado-core'),
				'description' => esc_html__('This option is only available for solid button type', 'mikado-core')
			),
			array(
				'type'        => 'textfield',
				'name'        => 'border_color',
				'title'       => esc_html__('Border Color', 'mikado-core'),
				'description' => esc_html__('This option is only available for solid and outline button type', 'mikado-core')
			),
			array(
				'type'        => 'textfield',
				'name'        => 'hover_border_color',
				'title'       => esc_html__('Hover Border Color', 'mikado-core'),
				'description' => esc_html__('This option is only available for solid and outline button type', 'mikado-core')
			),
			array(
				'type'        => 'textfield',
				'name'        => 'margin',
				'title'       => esc_html__('Margin', 'mikado-core'),
				'description' => esc_html__('Insert margin in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'mikado-core')
			)
		);
	}

	/**
	 * Generates widget's HTML
	 *
	 * @param array $args args from widget area
	 * @param array $instance widget's options
	 */
	public function widget($args, $instance) {
		$params = '';

		if (!is_array($instance)) { $instance = array(); }

		// Filter out all empty params
		$instance = array_filter($instance, function($array_value) { return trim($array_value) != ''; });

		// Default values
		if (!isset($instance['text'])) { $instance['text'] = 'Button Text'; }

		// Generate shortcode params
		foreach($instance as $key => $value) {
			$params .= " $key='$value' ";
		}

		echo '<div class="widget mkd-button-widget">';
			echo do_shortcode("[mkd_button $params]"); // XSS OK
		echo '</div>';
	}
}